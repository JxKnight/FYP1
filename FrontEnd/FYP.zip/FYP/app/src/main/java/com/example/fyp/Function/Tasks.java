package com.example.fyp.Function;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.fyp.R;

public class Tasks extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tasks);
    }
}
