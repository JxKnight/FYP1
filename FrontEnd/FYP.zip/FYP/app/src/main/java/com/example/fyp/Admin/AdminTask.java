package com.example.fyp.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.fyp.R;

public class AdminTask extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_task);
    }
}
