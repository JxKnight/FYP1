package com.example.fyp.Repository;

public interface ReportRepository {
}
