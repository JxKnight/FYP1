package com.example.fyp.Repository;

public interface TaskRepository {
}
