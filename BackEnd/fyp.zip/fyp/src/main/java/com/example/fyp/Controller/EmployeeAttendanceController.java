package com.example.fyp.Controller;

public class EmployeeAttendanceController {

//    @GetMapping("attendance")
//    public static BufferedImage generateEAN13BarcodeImage(String barcodeText) throws Exception {
//        Barcode barcode = BarcodeFactory.createEAN13(barcodeText);
//        barcode.setFont();
//
//        return BarcodeImageHandler.getImage(barcode);
//    }
}
